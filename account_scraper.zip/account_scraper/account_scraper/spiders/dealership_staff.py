import scrapy
import html
import re


class DealershipStaffSpider(scrapy.Spider):
    name = "dealership_staff"
    start_urls = [
        "https://www.saveatsterling.com",
        "https://www.sterlingfordopelousas.com",
        "https://www.sterlingchryslerdodgejeepramwest.com",
        "https://www.mausnissan.com",
        "https://www.mausnissantampa.com",
        "https://www.mausacura.com",
        "https://www.richardsonchevygladwin.com",
        "https://www.mercedeshoffman.com",
        "https://www.gatewayfargo.com",
        "https://www.langwaytoyotaofnewport.com",
        "https://www.jerryshyundai.com",
        "https://www.elktonford.com",
        "https://www.joececconischryslercomplex.com",
        "https://www.davisorangeburgtoyota.com",
        "https://www.garveyhyundai.com",
        "https://www.valorford.com",
        "https://www.myimageauto.com",
    ]
    
    custom_settings = {
        'USER_AGENT': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }

    # Deduplication set
    seen_staff = set()

    def decode_cloudflare_email(self, protected_email):
        try:
            key = int(protected_email[:2], 16)
            decoded_email = ''.join(
                chr(int(protected_email[i:i+2], 16) ^ key)
                for i in range(2, len(protected_email), 2)
            )
            return html.unescape(decoded_email)
        except Exception as e:
            self.logger.error(f"Error decoding email: {e}")
            return None

    def parse(self, response):
        staff_links = response.xpath(
            '//a[contains(text(), "Staff") or contains(text(), "Team") or contains(@href, "staff") or contains(@href, "about-us")]/@href'
        ).extract()

        for link in staff_links:
            full_link = response.urljoin(link)
            if "staff" in full_link or "about-us" in full_link:
                yield scrapy.Request(full_link, callback=self.parse_staff_page)

    def parse_staff_page(self, response):
        staff_items = response.xpath('//li[contains(@class, "staff-item")]')

        if staff_items:
            for staff in staff_items:
                name = staff.xpath('.//h3/text()').get()
                title = staff.xpath('.//h4/text()').get()

                obfuscated_email_href = staff.xpath('.//a[contains(@href, "cdn-cgi/l/email-protection")]/@href').get()
                email = None
                if obfuscated_email_href:
                    encoded_email = obfuscated_email_href.split('#')[-1]
                    email = self.decode_cloudflare_email(encoded_email)

                phone_div = staff.xpath('.//div[contains(@class, "staffphone")]/text()').getall()
                phone = "".join([line.strip() for line in phone_div if line.strip()])
                phone = re.sub(r'\s+', '', phone) if phone else None

                bio = staff.xpath('.//div[contains(@class, "bio")]/p//text()').getall()
                bio = " ".join([line.strip() for line in bio]) if bio else None
                image_url = staff.xpath('.//img[contains(@class, "staffpic")]/@src').get()

                staff_data = {
                    "name": name.strip() if name else None,
                    "title": title.strip() if title else None,
                    "email": email if email else None,
                    "phone_number": phone if phone else None,
                    "bio": bio.strip() if bio else None,
                    "image_url": response.urljoin(image_url) if image_url else None,
                    "source_url": response.url,
                }

                # Generate a unique key for deduplication
                unique_key = (staff_data["name"], staff_data["email"], staff_data["source_url"])

                # Exclude empty records and avoid duplicates
                if unique_key not in self.seen_staff and any(
                    staff_data[key] for key in ["name", "title", "email", "phone_number", "bio"]
                ):
                    self.seen_staff.add(unique_key)
                    yield staff_data

        else:
            staff_sections = response.xpath(
                '//dl[contains(@class, "vcard")] | '
                '//div[contains(@class, "cvcard")] | '
                '//div[contains(@class, "staff")] | '
                '//div[contains(@class, "employee-card")]'
            )

            for staff in staff_sections:
                name = staff.xpath(
                    './/dt[@class="fn"]/a/text() | '
                    './/h3/text() | '
                    './/div[contains(@class, "name")]/text() | '
                    './/div[contains(@class, "cvcard-name")]/text()'
                ).get()

                title = staff.xpath(
                    './/dd[@class="title"]/text() | '
                    './/p[contains(@class, "title") or contains(@class, "position") or contains(@class, "cvcard-title")]/text()'
                ).get()

                email = staff.xpath(
                    './/dd[@class="email"]/text() | '
                    './/a[contains(@href, "mailto:")]/@href'
                ).get(default='').replace("mailto:", "")

                phone = staff.xpath(
                    './/dd[@class="phone"]/text() | '
                    './/a[contains(@href, "tel:")]/@href'
                ).get(default='').replace("tel:", "")

                bio = staff.xpath(
                    './/dd[@class="bio"]/p//text() | '
                    './/p[contains(@class, "description")]//text()'
                ).getall()
                bio = " ".join([line.strip() for line in bio]) if bio else None

                image_url = staff.xpath(
                    './/dd[@class="photo"]//img/@src | '
                    './/img/@src'
                ).get()

                staff_data = {
                    "name": name.strip() if name else None,
                    "title": title.strip() if title else None,
                    "email": email.strip() if email else None,
                    "phone_number": phone.strip() if phone else None,
                    "bio": bio.strip() if bio else None,
                    "image_url": response.urljoin(image_url) if image_url else None,
                    "source_url": response.url,
                }

                unique_key = (staff_data["name"], staff_data["email"], staff_data["title"], staff_data["source_url"])
                if unique_key not in self.seen_staff and any(
                    staff_data[key] for key in ["name", "title", "email", "phone_number", "bio"]
                ):
                    self.seen_staff.add(unique_key)
                    yield staff_data
